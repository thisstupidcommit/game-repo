int test() {
	
    layout() out vec4(1.0,0.0,1.0,1.0) diffuseColor;
	return 1;
}